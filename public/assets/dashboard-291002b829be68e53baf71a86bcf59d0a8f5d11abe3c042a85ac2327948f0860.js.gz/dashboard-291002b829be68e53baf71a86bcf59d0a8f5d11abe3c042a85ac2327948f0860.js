$(function () {
    //Widgets count
    $('.count-to').countTo();

   
});

